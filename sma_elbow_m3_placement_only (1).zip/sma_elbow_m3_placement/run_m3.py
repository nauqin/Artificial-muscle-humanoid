import sys, os, json, math, numpy as np
D = os.path.dirname(os.path.abspath(__file__)); os.chdir(D); sys.path.insert(0, D)
g = {'__file__': os.path.join(D, 'place_elbow.py'), '__name__': 'pe'}
exec(open('place_elbow.py', encoding='utf-8').read().split("if __name__ == '__main__':")[0], g)
ns = g['lift_ns'](); REF = ns['prepare']()
xml, n = sys.argv[1], int(sys.argv[2])
F = {c: 450.0 * n for c in g['CABLES']}; S = {c: 0.40 * 0.18 for c in g['CABLES']}     # 기계연 M3 × n: 450 N, 0.18 m, 0.40
ns['use'](xml, F, S); R = ns['simulate']('custom', REF); e = R[:, 2] - R[:, 1]
print(json.dumps(dict(xml=xml, n=n, rms=round(float(np.sqrt(np.mean(e**2))), 2), qmax=round(float(R[:, 2].max()), 1),
      Tmax=round(float(R[:, 3:5].max()), 1), Fb=round(float(R[:, 5].max())), Ft=round(float(R[:, 6].max())))), flush=True)
