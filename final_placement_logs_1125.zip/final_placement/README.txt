Final placement = refined on the calibrated model from thermal-delay beta 0.15 (out/3단계/s3_new_top.json).
count_new_final.log: M3 x13..20, 10 runs.  opencap_final10.log: 6 OpenCap conditions, 10 runs (reach_forward not available here).
Geometry: flexor contraction 64.9 mm, min length 184 mm, moment arm 8.3-33.6 mm; extensor 68.9 mm, 246 mm, 7.6-35.7 mm.
