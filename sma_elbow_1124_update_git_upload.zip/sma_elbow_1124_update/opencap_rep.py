"""OpenCap 동작 반복 (1 mm 흔들기, 모든 배치에 같은 흔들기). 사용: python opencap_rep.py N TAG files... -- trial:t0:t1:kg[:sp] ..."""
import os, sys, json, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
ARGV = list(sys.argv)
import opt_m3 as o, opencap_eval as oe
if __name__ == '__main__':
    from multiprocessing import Pool
    N, TAG = int(ARGV[1]), ARGV[2]; k = ARGV.index('--'); files, specs = ARGV[3:k], ARGV[k + 1:]
    cand = []
    for f in files:
        d = json.load(open(f)); x = d['opt'] if 'opt' in d else d[0]['x']
        get = (lambda n: x[n]['x']) if 'opt' in d else (lambda n: x[n])
        cand.append((os.path.basename(f)[:-5], get('elbow_M0_r'), get('elbow_M1_r')))
    trials = [(s.split(':') + ['1'])[:5] for s in specs]
    jobs = [(c[0], c[1], c[2], 90001 + j, tr, float(t0), float(t1), float(kg), float(sp)) for c in cand for (tr, t0, t1, kg, sp) in trials for j in range(N)]
    with Pool(2, initializer=o._init) as p: res = p.map(oe.job, jobs)
    out = {}
    for tag, tr, r, _ in res: out.setdefault(tag, {}).setdefault(tr, []).append(r)
    for c in cand:
        print(f"{c[0]:16s} " + '  '.join(f"{tr}: {np.median(v):5.1f}° [{min(v):.1f}~{max(v):.1f}] ({sum(x > 25 for x in v)}/{len(v)})" for tr, v in out[c[0]].items()), flush=True)
    json.dump(out, open(os.path.join(HERE, 'out', f'ocrep_{TAG}.json'), 'w'), ensure_ascii=False)
