cd /home/claude/exp/m3v_s2
while [ ! -f out/s1/done ]; do sleep 10; done
for b in 0.05 0.1 0.15 0.3 0.4 0.6; do echo $b; done | xargs -P 2 -I{} sh -c 'python static_var.py path {} out/s1/beta_{}.json > out/s1/beta_{}.log 2>&1'
mkdir -p out/s1b; cp out/s1/beta_*.json out/s1b/
NEWM=1 NM3=25 JIT=1e-3 python eval_sv.py 10 out/s1b/*.json > out/s1/beta_new10.log 2>&1
NM3=5 JIT=1e-3 python eval_sv.py 10 out/s1b/*.json > out/s1/beta_v3_10.log 2>&1
echo DONE > out/s1/beta_done
