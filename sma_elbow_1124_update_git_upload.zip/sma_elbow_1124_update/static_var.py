"""다른 종류의 정적 식 (160 cm, M3 72 mm). 사용: python static_var.py MODE BETA OUT
MODE: path(기존) · range(모든 자세) · heat(열 지연 0.5 s) · mean(평균 힘) · load(무게에 따른 수축 감소, M3×25) · arm(모멘트암 최대화)"""
import sys, os, json, math, numpy as np
D = os.path.dirname(os.path.abspath(__file__)); os.chdir(D); sys.path.insert(0, D)
MODE, BETA, OUT = sys.argv[1], float(sys.argv[2]), sys.argv[3]; sys.argv = ['x']
g = {'__file__': os.path.join(D, 'place_elbow.py'), '__name__': 'pe'}
exec(open('place_elbow.py', encoding='utf-8').read().split("if __name__ == '__main__':")[0], g)
S = 0.40 * 0.18
G, yubin = g['task']('range' if MODE == 'range' else 'path')
if MODE == 'heat':                       # 열 지연: 지금 자세에서 앞으로 0.5 s 안에 올 최대 토크를 낼 수 있어야
    nt, t = G['nt'], G['t']
    for key in ('tauF', 'tauE'):
        a = G[key].copy(); b = a.copy()
        for i in range(nt):
            j = np.searchsorted(t, t[i] + 0.5, side='right'); b[i] = a[i:max(j, i + 1)].max()
        G[key] = b
sys.path.insert(0, os.environ.get('NMOD_DIR', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'new_model_1122'))); import new_model as NMOD
NW = 25
def evaluate(G, X, cable, S, fit=True):
    sign = g['SIGN'][cable]; L, r = g['lengths'](G, X); rr = sign * r
    s = L.max(1, keepdims=True) - L; use = s.max(1)
    tau_c = (G['tauF'] if sign > 0 else G['tauE'])[None]
    Freq = np.where(tau_c > 1e-6, tau_c / np.maximum(rr, 1e-3), 0.0)
    if MODE == 'load':                   # 가닥당 힘이 46 N 넘으면 최대 수축이 줄어듦 → 쓸 수 있는 스트로크 S_eff
        f = Freq / NW; eff = np.where(f <= NMOD.F1, NMOD.EPS, np.maximum(NMOD.EPS - NMOD.SLOPE * (f - NMOD.F1), 1e-3))
        Seff = S * eff / NMOD.EPS
        fac = np.minimum(1.0, (1 - s / Seff) / BETA)
    else:
        fac = np.minimum(1.0, (1 - s / S) / BETA)
    Ft = np.where(tau_c > 1e-6, Freq / np.maximum(fac, 1e-3), 0.0)
    F = Ft.max(1)
    if MODE == 'mean': obj = np.where(tau_c > 1e-6, Ft, np.nan); obj = np.nanmean(obj[:, :G['nt']], 1)
    elif MODE == 'arm': obj = -rr[:, :G['nt']].mean(1) * 1e4
    else: obj = F
    v = np.maximum(0, use - S) / S + np.maximum(0, g['R_MIN'] - rr.min(1)) / g['R_MIN'] + np.maximum(0, g['CLEAR'] - g['clearance'](G, X)) / g['CLEAR']
    if fit: v = v + np.maximum(0, S / g['EPSL'] - L.min(1)) / (S / g['EPSL'])
    if MODE == 'load': v = v + np.where(np.isfinite(F) & (F < 1e8), 0, 1)
    return np.where(v > 0, 1e5 * (1 + 10 * v), obj), np.where(v > 0, np.inf, F), use, rr.min(1), L.min(1)
g['evaluate'] = evaluate
out = {'S': S, 'mode': MODE, 'beta': BETA, 'opt': {}}
for n in g['CABLES']:
    r = g['optimize'](G, n, S, True); out['opt'][n] = r
    print(MODE, BETA, n, 'F_need', round(r['F_need']), 'r_min', round(r['r_min'] * 1000, 1), 'mm', flush=True)
json.dump(out, open(OUT, 'w'), indent=1)
