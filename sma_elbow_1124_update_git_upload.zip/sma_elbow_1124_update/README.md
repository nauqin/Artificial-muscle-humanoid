# 팔꿈치 인공근육 배치 — 정적 식 20종 비교와 3단계 (11/24, 정어진)

기존 `sma_elbow_m3_placement` 폴더(11/23)에 이어지는 작업이다. 같은 팔(나유빈 160 cm 최종 A안 팔꿈치), 같은 과제(물병 3.79 kg 들기), 같은 조건(수축 ≤ 72 mm, 케이블 ≥ 0.18 m, 모멘트암 ≥ 5 mm, 뼈 거리 ≥ 20 mm)을 쓴다.

## 바뀐 점
- **근육 모델 두 개:** 김은서 v3(`sma_model.py`, M3×5)와 김은서 11/22 보정 모델(`new_model_1122/`, 깃 sma_arm_kimm/new_model_1122 그대로, M3×25)
  - 보정 모델은 환경 변수 `NEWM=1`로 켠다 (`opt_m3.py`, `lift_finalA.py`).
  - 보정 모델 폴더 위치는 `NMOD_DIR`로 바꿀 수 있다 (기본: 이 폴더의 `new_model_1122`).
  - 보정 모델의 온도 목표는 39~105 °C다 (`TSTAND`, `TSPAN`). v3의 52~92 °C와 같은 규칙(변태 시작 −3 °C ~ 끝 +20 °C)으로 정했다.
- **정적 식 20종** (`static_var.py MODE BETA OUT`)
  - MODE: path(기본 식), range(모든 자세), heat(열 지연 0.5 s), mean(평균 힘), load(무게에 따른 수축 감소), arm(모멘트암 최대화)
- **평가:** 모든 배치에 같은 1 mm 오차를 넣는다 (`eval_sv.py N files...`, 시드 70000~). 그래서 배치끼리 공정하게 비교되고, 다시 돌려도 같은 값이 나온다.

## 순서
| 단계 | 스크립트 | 결과 |
|---|---|---|
| 1단계: 정적 20종 거르기 (두 모델, 10회) | `run_s1.sh`, `run_beta.sh` | `out/1단계_정적20종/` (`new10.log`, `v3_10.log`, `beta_*.log`) |
| 2단계: MuJoCo 확인 (30회) | `run_s2.sh` | `out/3단계/new30.json`, `v330.json` (배치 파일은 `out/2단계_30회/`) |
| 3단계: MuJoCo 최적화로 다듬기 | `run_s3.sh` (CMA-ES 12세대, `OPT_NJ=4`, `JIT=1e-3`) | `out/3단계/s3_new_top.json`, `s3_v3_top.json`, 30회 평가 `s3_new30.json`, `s3_v330.json` |
| OpenCap 7동작 (보정 모델, 3회) | `run_oc.sh` → `opencap_rep.py` | `out/opencap/` |
| 근육 수 (보정 모델) | `count_new.py` | `out/new_count_A_main.json`, `countB.log`, `countC.log` |

- **최종 배치:** `out/3단계/s3_v3_top.json` (MuJoCo ← 열 지연 β 0.01)
- **결과 요약:** `정적식_3단계_정리_1124.md`

## 주의
- OpenCap 동작 파일(.mot)과 OpenSim 모델 파일은 넣지 않았다. 기존 폴더와 같은 입력 파일이 필요하다.
- 기계연 원시 측정 데이터는 넣지 않았다.
