import os, sys, json, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import opt_m3 as o, eval_new as E
if __name__ == '__main__':
    from multiprocessing import Pool
    N = int(sys.argv[1]); cand = [c for c in E.cands() if not c[0].startswith('v3')]
    jobs = [(c[0], c[1], c[2], 70000 + 100 * i + j) for i, c in enumerate(cand) for j in range(N)]
    with Pool(2, initializer=o._init) as p: res = p.map(E.job, jobs)
    out = {}
    for t, r in res: out.setdefault(t, []).append(r)
    for c in cand:
        v = np.array(out[c[0]]); print(f"M3×{o.NM3} | {c[0]:16s} 중앙값 {np.median(v):5.1f}°  범위 {v.min():5.1f}~{v.max():5.1f}°  실패(>25°) {int((v > 25).sum())}/{N}", flush=True)
    json.dump(out, open(os.path.join(HERE, 'out', f'new_eval_{o.NM3}_{N}.json'), 'w'), ensure_ascii=False)
