cd /home/claude/exp/m3v_s2
NEWM=1 NM3=25 JIT=1e-3 python eval_sv.py 10 out/s1/*.json > out/s1/new10.log 2>&1
NM3=5 JIT=1e-3 python eval_sv.py 10 out/s1/*.json > out/s1/v3_10.log 2>&1
echo DONE > out/s1/done
