cd /home/claude/exp/m3v_s2
NEWM=1 NM3=25 JIT=1e-3 python opencap_rep.py 3 new3 out/oc/*.json -- bottle2kg_2:1:43.5:2.0 bottle2kg_1:1.5:42.5:3.79 bottle2kg_1:1.5:42.5:3.79:2 box_empty_2:1:59.5:0.4 reach_forward_1_1:1:35.5:0 shoulder_front_1:1:37.5:0 shoulder_side_1:1:59.5:0 > out/oc/new3.log 2>&1
echo DONE > out/oc/done
