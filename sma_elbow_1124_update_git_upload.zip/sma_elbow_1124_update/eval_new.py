"""새 모델(NEWM=1): 배치 8종을 10번(부착점 1 mm 흔들기) 돌려 데이터셋 물병 오차 비교"""
import sys, os, json, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import opt_m3 as o
def job(a):
    tag, xf, xe, seed = a
    if not o._W: o._init()
    return tag, o.run_once(np.array(xf), np.array(xe), {}, seed)
def cands():
    o._init(); g = o._W['g']; G, yubin = g['task']('path'); J = lambda f: json.load(open(os.path.join(HERE, f)))
    st, sy, s2 = J('out/static_m3.json')['opt'], J('out/static_yubin.json')['opt'], J('out/static_mine2.json')['opt']
    c = [('기존 설계 배치', yubin['elbow_M0_r'].tolist(), yubin['elbow_M1_r'].tolist()),
         ('정적 A', st['elbow_M0_r']['x'], st['elbow_M1_r']['x']), ('정적 B', sy['elbow_M0_r']['x'], sy['elbow_M1_r']['x']),
         ('정적 C', s2['elbow_M0_r']['x'], s2['elbow_M1_r']['x'])]
    for tag, f in (('MuJoCo (A 시작)', 'out/new_optA_top.json'), ('MuJoCo (C 시작)', 'out/new_optC_top.json'),
                   ('v3 MuJoCo (A 시작)', '/home/claude/exp/m3v/out/optm3_5_top.json'), ('v3 MuJoCo (C 시작)', 'out/optm3_5_top.json')):
        p = f if f.startswith('/') else os.path.join(HERE, f)
        if os.path.exists(p): x = json.load(open(p))[0]['x']; c.append((tag, x['elbow_M0_r'], x['elbow_M1_r']))
    return c
if __name__ == '__main__':
    from multiprocessing import Pool
    N = int(sys.argv[1]); cand = cands()
    jobs = [(c[0], c[1], c[2], 70000 + 100 * i + j) for i, c in enumerate(cand) for j in range(N)]
    with Pool(2, initializer=o._init) as p: res = p.map(job, jobs)
    out = {}
    for t, r in res: out.setdefault(t, []).append(r)
    summ = {}
    for c in cand:
        v = np.array(out[c[0]]); summ[c[0]] = dict(runs=v.tolist(), median=float(np.median(v)), fail=int((v > 25).sum()), x=[c[1], c[2]])
        print(f"새 모델 M3×{o.NM3} | {c[0]:18s} 중앙값 {np.median(v):5.1f}°  범위 {v.min():5.1f}~{v.max():5.1f}°  실패(>25°) {int((v > 25).sum())}/{N}", flush=True)
    json.dump(summ, open(os.path.join(HERE, 'out', f'new_eval_{o.NM3}.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
