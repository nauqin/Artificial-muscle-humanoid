import os, sys, json, glob, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import opt_m3 as o, eval_new as E
if __name__ == '__main__':
    from multiprocessing import Pool
    N = int(sys.argv[1]); files = sys.argv[2:]
    cand = []
    for f in files:
        d = json.load(open(f)); x = d['opt'] if 'opt' in d else d[0]['x']
        get = (lambda n: x[n]['x']) if 'opt' in d else (lambda n: x[n])
        cand.append((os.path.basename(f)[:-5], get('elbow_M0_r'), get('elbow_M1_r')))
    jobs = [(c[0], c[1], c[2], 70000 + j) for c in cand for j in range(N)]
    with Pool(2, initializer=o._init) as p: res = p.map(E.job, jobs)
    out = {}
    for t, r in res: out.setdefault(t, []).append(r)
    for c in sorted(cand, key=lambda c: np.median(out[c[0]])):
        v = np.array(out[c[0]]); print(f"M3×{o.NM3} | {c[0]:18s} 중앙값 {np.median(v):5.1f}°  범위 {v.min():5.1f}~{v.max():5.1f}°  실패 {int((v > 25).sum())}/{N}", flush=True)
    json.dump(out, open(os.environ.get('EVOUT', os.path.join(HERE, 'out', 'sv', f'eval_{o.NM3}_{N}.json')), 'w'))
