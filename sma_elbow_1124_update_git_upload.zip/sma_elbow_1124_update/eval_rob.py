import os, sys, json, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import opt_m3 as o, eval_new as E
if __name__ == '__main__':
    from multiprocessing import Pool
    N = int(sys.argv[1]); J = lambda f: json.load(open(os.path.join(HERE, f)))[0]['x']
    cand = [(t, J(f)['elbow_M0_r'], J(f)['elbow_M1_r']) for t, f in
            (('MuJoCo (A 시작)', 'out/new_optA_top.json'), ('MuJoCo (C 시작)', 'out/new_optC_top.json'),
             ('강건 (최종에서)', 'out/rob_C_top.json'), ('강건 (정적 B에서)', 'out/rob_B_top.json'))]
    jobs = [(c[0], c[1], c[2], 70000 + 100 * i + j) for i, c in enumerate(cand) for j in range(N)]
    with Pool(2, initializer=o._init) as p: res = p.map(E.job, jobs)
    out = {}
    for t, r in res: out.setdefault(t, []).append(r)
    for c in cand:
        v = np.array(out[c[0]]); print(f"M3×{o.NM3} | {c[0]:14s} 중앙값 {np.median(v):5.1f}°  범위 {v.min():5.1f}~{v.max():5.1f}°  실패 {int((v > 25).sum())}/{N}", flush=True)
