cd /home/claude/exp/m3v_s2
export JIT=1e-3 OPT_NJ=4
NEWM=1 NM3=25 OPT_START=out/start_heat015.json OPT_SEED0=1300 python opt_m3.py 12 0.04 > out/s2res/s3_new.out 2>&1
cp out/optm3_25_top.json out/s2res/s3_new_top.json
NM3=5 OPT_START=out/start_heat001.json OPT_SEED0=1700 python opt_m3.py 12 0.04 > out/s2res/s3_v3.out 2>&1
cp out/optm3_5_top.json out/s2res/s3_v3_top.json; cp out/optm3_5_top_Cstart_bak.json out/optm3_5_top.json; cp out/optm3_5_log_Cstart_bak.json out/optm3_5_log.json
echo DONE > out/s2res/s3done
