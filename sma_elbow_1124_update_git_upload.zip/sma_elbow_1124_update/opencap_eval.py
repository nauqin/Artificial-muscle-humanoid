"""OpenCap 내 동작(최적화에 안 쓴 동작)으로 160 cm 배치 6종 검증
목표 = OpenCap elbow_flex_r (6 Hz 저역 통과), 중력 방향 = OpenCap 몸통·어깨 각도, 손 하중 = 실제 든 무게
사용: NM3=5 JIT=1e-3 python opencap_eval.py <N> <trial:t0:t1:kg> ...
"""
import sys, os, json, math, numpy as np
from scipy.signal import butter, filtfilt
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import opt_m3 as o
OC = os.environ.get('OC_DIR', '/home/claude/exp/opencap/in')
HAND = 0.24288          # 손 질량 (모델 4.03288 kg = 손 + 물병 3.79 kg)

def read(f):
    L = open(f).read().splitlines(); i = [k for k, l in enumerate(L) if l.strip() == 'endheader'][0]
    h = L[i + 1].split('\t'); d = np.array([[float(x) for x in l.split()] for l in L[i + 2:] if l.strip()]); return h, d

def make_ref(trial, t0, t1, sp=1.0):
    ns = o._W['ns']; h, d = read(os.path.join(OC, trial + '.mot')); t = d[:, 0]
    b, a = butter(2, 6 / (0.5 / np.median(np.diff(t))))
    col = lambda c: filtfilt(b, a, d[:, h.index(c)]) * math.pi / 180
    k = (t >= t0) & (t <= t1); tt = t[k] - t[k][0]
    CH = ns['chain'](ns['find'](ns['NAME'] + '_model.osim'))
    rot = ['pelvis_tilt', 'pelvis_list', 'pelvis_rotation', 'lumbar_extension', 'lumbar_bending', 'lumbar_rotation', 'arm_flex_r', 'arm_add_r', 'arm_rot_r']
    C = {c: col(c)[k] for c in rot}; R90 = ns['rx'](math.pi / 2)
    grav = np.array([R90 @ (ns['humerus_R'](CH, {c: C[c][j] for c in rot}).T @ np.array([0, -9.81, 0])) for j in range(len(tt))])
    return dict(t=tt / sp, qref=col('elbow_flex_r')[k], grav=grav)

def job(a):
    tag, xf, xe, seed, trial, t0, t1, kg, sp = a
    if not o._W: o._init()
    REF = make_ref(trial, t0, t1, sp); g, ns = o._W['g'], o._W['ns']
    rng = np.random.default_rng(seed); X = {'elbow_M0_r': np.array(xf) + rng.normal(0, o.JIT, 6), 'elbow_M1_r': np.array(xe) + rng.normal(0, o.JIT, 6)}
    p = g['xml_from'](X, o._W['tmp']); s = open(p).read()
    assert 'mass="4.03288"' in s
    open(p, 'w').write(s.replace('mass="4.03288"', f'mass="{HAND + kg:.5f}"'))
    o.set_muscle(p, {'elbow_M0_r': o.S_M3, 'elbow_M1_r': o.S_M3}); R = ns['simulate']('custom', REF)
    e = R[:, 2] - R[:, 1]
    return tag, f'{trial}@{kg:g}kg×{sp:g}', float(np.sqrt(np.mean(e ** 2))), R[::200].tolist() if seed % 100 == 0 else None

if __name__ == '__main__':
    from multiprocessing import Pool
    N = int(sys.argv[1]); trials = [(a.split(':') + ['1'])[:5] for a in sys.argv[2:]]
    o._init(); g = o._W['g']; G, yubin = g['task']('path')
    J = lambda f: json.load(open(f))
    st, sy, s2 = J('out/static_m3.json')['opt'], J('out/static_yubin.json')['opt'], J('out/static_mine2.json')['opt']
    if os.environ.get('NEWM') == '1': m1 = J('out/new_optA_top.json')[0]['x']; m2 = J('out/new_optC_top.json')[0]['x']
    else: m1 = J(f'/home/claude/exp/m3v/out/optm3_{o.NM3}_top.json')[0]['x']; m2 = J(f'out/optm3_{o.NM3}_top.json')[0]['x']
    cand = [('기존 설계 배치', yubin['elbow_M0_r'].tolist(), yubin['elbow_M1_r'].tolist()),
            ('정적 A', st['elbow_M0_r']['x'], st['elbow_M1_r']['x']),
            ('정적 B', sy['elbow_M0_r']['x'], sy['elbow_M1_r']['x']),
            ('정적 C', s2['elbow_M0_r']['x'], s2['elbow_M1_r']['x']),
            ('MuJoCo (A 시작)', m1['elbow_M0_r'], m1['elbow_M1_r']),
            ('MuJoCo (C 시작)', m2['elbow_M0_r'], m2['elbow_M1_r'])]
    mp = f'out/multi_{o.NM3}_top.json'
    if os.path.exists(mp) and os.environ.get('MULTI'):
        mm = J(mp)[0]['x']; cand.append(('MuJoCo 다중 동작', mm['elbow_M0_r'], mm['elbow_M1_r']))
    if os.environ.get('ONLY'): cand = [c for c in cand if c[0] in os.environ['ONLY'].split(',')]
    jobs = [(c[0], c[1], c[2], 90000 + 100 * i + j, tr, float(t0), float(t1), float(kg), float(sp)) for i, c in enumerate(cand) for (tr, t0, t1, kg, sp) in trials for j in range(N)]
    with Pool(2, initializer=o._init) as p: res = p.map(job, jobs)
    out = {}; traces = {}
    for tag, tr, r, R in res:
        out.setdefault(tag, {}).setdefault(tr, []).append(r)
        if R is not None: traces[f'{tag}|{tr}'] = R
    for c in cand:
        print(f"M3×{o.NM3} | {c[0]:14s} " + '  '.join(f"{tr}: {np.median(v):5.1f}° ({sum(x > 25 for x in v)}/{len(v)})" for tr, v in out[c[0]].items()), flush=True)
    tagn = os.environ.get('TAG', '')
    json.dump(dict(res=out, traces=traces), open(f'out/opencap_M3x{o.NM3}{tagn}.json', 'w'), ensure_ascii=False)
