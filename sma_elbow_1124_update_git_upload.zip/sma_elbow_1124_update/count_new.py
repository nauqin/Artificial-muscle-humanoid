import os, sys, json, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import opt_m3 as o
def job(a):
    n, xf, xe, seed = a
    o.NM3 = n; o._W['tmp'] = os.path.join(HERE, 'out', f'_opt_{os.getpid()}.xml')
    return n, o.run_once(np.array(xf), np.array(xe), {}, seed)
if __name__ == '__main__':
    from multiprocessing import Pool
    ARGV = list(sys.argv); o._init()
    x = json.load(open(os.path.join(HERE, ARGV[1])))[0]['x']; Ns = [int(v) for v in ARGV[2].split(',')]; R = int(ARGV[3])
    jobs = [(n, x['elbow_M0_r'], x['elbow_M1_r'], 70000 + j) for n in Ns for j in range(R)]
    with Pool(2) as p: res = p.map(job, jobs)
    out = {}
    for n, r in res: out.setdefault(n, []).append(r)
    for n in Ns:
        v = np.array(out[n]); print(f'M3×{n:2d} | 중앙값 {np.median(v):5.1f}°  범위 {v.min():5.1f}~{v.max():5.1f}°  실패(>25°) {int((v > 25).sum())}/{R}', flush=True)
    json.dump({str(k): v for k, v in out.items()}, open(os.path.join(HERE, 'out', f'new_count_{os.path.basename(ARGV[1])}'), 'w'))
