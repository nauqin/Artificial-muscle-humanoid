cd /home/claude/exp/m3v_s2
EVOUT=out/s2res/new30.json NEWM=1 NM3=25 JIT=1e-3 python eval_sv.py 30 out/s2/*.json > out/s2res/new30.log 2>&1
EVOUT=out/s2res/v330.json NM3=5 JIT=1e-3 python eval_sv.py 30 out/s2/[!M]*.json out/s2/v3opt/*.json > out/s2res/v330.log 2>&1
echo DONE > out/s2res/done
