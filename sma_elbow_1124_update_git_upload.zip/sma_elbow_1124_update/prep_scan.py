# 새 모델 대비: 한 가닥 힘(FM3)을 낮췄을 때 가닥 수(NM3) · 제어(KP,KD)별 데이터셋 물병 오차
import os, sys, json, time, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
def job(a):
    tag, xf, xe, nm3, kp, kd, seed = a
    os.environ['NM3'] = str(nm3)
    import opt_m3 as o
    o.NM3 = nm3
    o._W['tmp'] = os.path.join(HERE, 'out', f'_opt_{os.getpid()}.xml')
    ns = o._W['ns']; lf = ns  # KP/KD are module globals inside lift ns
    ns['KP'], ns['KD'] = kp, kd
    rng = np.random.default_rng(seed)
    X = {'elbow_M0_r': np.array(xf) + rng.normal(0, 1e-3, 6), 'elbow_M1_r': np.array(xe) + rng.normal(0, 1e-3, 6)}
    o.set_muscle(o._W['g']['xml_from'](X, o._W['tmp']), {}); R = ns['simulate']('custom', o._W['REF'])
    e = R[:, 2] - R[:, 1]; return tag, nm3, kp, kd, float(np.sqrt(np.mean(e ** 2)))
if __name__ == '__main__':
    from multiprocessing import Pool
    ARGV = list(sys.argv); J = lambda f: json.load(open(f))
    import opt_m3 as o; o._init(); g = o._W['g']; G, yubin = g['task']('path')
    print('KP in ns:', 'KP' in o._W['ns'])
    s2 = J('out/static_mine2.json')['opt']; m2 = J('out/optm3_5_top.json')[0]['x']; st = J('out/static_m3.json')['opt']
    cand = {'기존': (yubin['elbow_M0_r'].tolist(), yubin['elbow_M1_r'].tolist()),
            '정적A': (st['elbow_M0_r']['x'], st['elbow_M1_r']['x']),
            '정적C': (s2['elbow_M0_r']['x'], s2['elbow_M1_r']['x']),
            'MuJoCoC': (m2['elbow_M0_r'], m2['elbow_M1_r'])}
    grid = json.loads(ARGV[1])   # [[nm3,kp,kd],...]
    tags = ARGV[2].split(",") if len(ARGV) > 2 else list(cand)
    jobs = [(t, *cand[t], n, kp, kd, 7) for (n, kp, kd) in grid for t in tags]
    t0 = time.time()
    with Pool(2) as p: res = p.map(job, jobs)
    for r in res: print(f'{r[0]:8s} M3×{r[1]:2d} KP {r[2]:.3f} KD {r[3]:.3f} → {r[4]:5.1f}°')
    print(f'{time.time()-t0:.0f} s')
    out = 'out/prep_scan.json'; old = J(out) if os.path.exists(out) else []
    json.dump(old + [list(r) + [float(os.environ.get('FM3', 450))] for r in res], open(out, 'w'), ensure_ascii=False)
